document.getElementById('app').innerHTML = `
  <p>This will be your timetable generator UI.</p>
`;